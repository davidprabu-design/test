<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <link rel="stylesheet" type ="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type ="text/css" href="css/global.css">
        
    </head>
    <body>    
        <div>
            <h3 class="text-center mt-3 mb-3">Simple Rest-API</h3>
            <form class="form-container" action="#" method="POST">
                <input type="text" name="user_id" placeholder="User Id">&nbsp;
                <input type="text" name="name" placeholder="Name" required>&nbsp;
                <input type="number" name="number" placeholder="Mobile Number" required><br><br>
                <input type="email" name="mail" placeholder="E-mail" required>&nbsp;
                <input type="text" name="bgrp" placeholder="Blood Group" required>&nbsp;
                <input class = "btn btn-success" type="submit" name="submit" value="SUBMIT">&nbsp;<br>
                                
            </form>
        </div>
        
    
    <?php
        require_once 'connect.php';
        if(isset($_POST['submit'])){

            $user_id = $_POST['user_id'];
            $name = $_POST['name'];
            $number = $_POST['number'];
            $mail = $_POST['mail'];
            $bgrp = $_POST['bgrp'];

            $sql="INSERT INTO test_api VALUES (Null,'$user_id','$name','$number','$mail','$bgrp')";

            if($conn->query($sql)){
                echo "<script>alert('Success')</script>";
                header("Location:index.php");
            }else{
                echo "<script>alert(Error')</script>";
            }
        }
    ?>


    <?php $conn->close();?>

    
    <script src="js/bootstrap.min.js"></script>
    
    </body>
</html>
