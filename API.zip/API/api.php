<?php
    header("Content-Type:application/json");
    if(isset($_GET['user_id'])){
        include("connect.php");

        $user_id = $_GET['user_id'];

        $sql = "SELECT * FROM test_api WHERE user_id='$user_id'";
        // $sql = "SELECT * FROM test_api";

        $result = $conn->query($sql);

        if($result->num_rows > 0){
            $row = $result->fetch_array();

            $name = $row['name'];
            $number  = $row['number'];
            $mail = $row['mail'];
            $blood = $row['blood'];

            response($user_id,$name,$number,$mail,$blood);

            $conn->close();         

        }else{
            response(NULL,NULL,NULL,NULL,"Invalid Request");
        }

    }else{
        response(NULL,NULL,NULL,NULL,"Invalid Request");
    }


    function response($user_id,$name,$number,$mail,$blood){
        $response['user_id'] = $user_id;
        $response['name'] = $name;
        $response['number'] = $number;
        $response['mail'] = $mail;
        $response['blood'] = $blood;

        $json_response = json_encode($response);
        echo $json_response;
        
    }


?>
