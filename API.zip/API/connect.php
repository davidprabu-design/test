<?php
    $host = 'localhost';
    $user= 'root';
    $password = '';
    $db = 'api_db';

    $conn = new mysqli($host, $user, $password, $db);

    if($conn->connect_error){
        echo $conn->connect_error;
        die('Connection Error');
    }

?>